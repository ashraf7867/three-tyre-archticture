import React,{Component} from 'react';

export class Home extends Component{
    render(){
        return(
            <div>
                <h3>This is Home page for 9pm batch</h3>
            </div>
        )
    }
}