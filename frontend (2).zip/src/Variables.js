export const variables={
    API_URL:"https://backend786.azurewebsites.net/"
}